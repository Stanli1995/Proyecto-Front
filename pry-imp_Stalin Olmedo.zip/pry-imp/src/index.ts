

class producto {
    constructor(public nombreP: string, public precioP: number, public cantidadP: number, public id: string) {
        this.nombreP = nombreP;
        this.precioP = precioP;
        this.cantidadP = cantidadP;
        this.id = id;
    }
}

class factura {
    productos: producto[];
    total: number;
    subtotal: number;

    constructor() {
        this.productos = [];
        this.total = 0;
        this.subtotal = 0;
    }

    validar(producto: producto): boolean {
        var ban = false
        for (let i = 0; i < this.productos.length; i++) {
            if ((this.productos[i].id).localeCompare(producto.id) == 0) {
                ban = true;
            }
        }
        return ban;
    }

    agregarProducto(producto: producto) {
        console.log(this.validar(producto));
        if (this.validar(producto)) {
            for (let i = 0; i < this.productos.length; i++) {
                if ((this.productos[i].id).localeCompare(producto.id) == 0) {
                    (this.productos[i].cantidadP) += producto.cantidadP
                }
            }
        }
        else {
            this.productos.push(producto);
            console.log(this.productos);
        }
    }

    calcularProducto() {
        for (let i = 0; i < this.productos.length; i++) {
            this.subtotal += this.productos[i].precioP * this.productos[i].cantidadP;
            this.productos[i].precioP += this.impProducto(this.productos[i]);
            this.total += this.productos[i].precioP * this.productos[i].cantidadP;
        }
        console.log(this.productos);
    }

    impProducto(producto: producto): number {
        let impuesto = producto.precioP * 0.12;
        return impuesto;
    }

    verProductos() {
        this.productos.forEach((producto) => {
            console.log(` id: ${producto.id}, producto: ${producto.nombreP},Cantidad: ${producto.cantidadP}`)
        })
    }

    verTotales() {
        console.log(`Total: ${(this.total).toFixed(2)}`);
    }

    verSubTotales() {
        console.log(`SubTotal: ${this.subtotal}`);
    }

    verIva() {
        console.log(`Iva 12%: ${(this.total - this.subtotal).toFixed(2)}`);
    }

    imprimir() {
        this.verProductos();
        this.verSubTotales();
        this.verIva();
        this.verTotales();
    }
}

function random() {
    const newUID = Math.random().toString(36).slice(2)
    // console.log("Cod, ",newUID)
    return newUID
}

let n = new producto("leche", 3, 5, random());
let m = new producto("carne", 2, 3, random());
let f = new factura();

f.agregarProducto(n);
f.agregarProducto(m);
f.calcularProducto();
f.imprimir();



