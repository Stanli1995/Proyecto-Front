"use strict";
let lastName = "luis";
console.log("hola", lastName);
